/**********************************************************
	Az "eredeti" C kod include file-ja
**********************************************************/

#ifndef SHIFTREG_H_INCLUDED
#define SHIFTREG_H_INCLUDED
unsigned short	shiftreg( bool enable, bool serial_in, unsigned short data);	
#endif
