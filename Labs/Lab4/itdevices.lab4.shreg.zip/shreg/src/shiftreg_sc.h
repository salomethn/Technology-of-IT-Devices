/**********************************************************
 A shiftregisztert megvalosito "eredeti" C kod 
 SystemC burkolo osztalya.
 Itt mar a hardware irjuk le, C++ eszkozokkel.
**********************************************************/

#include <systemc.h>
#include "shiftreg.h"
#ifdef _DEBUG
#include <iomanip>
#include <bitset>
using namespace std;
#endif

SC_MODULE(shiftreg_sc)	// az SC_MODULE valojaban egy sc_module-bol szarmaztatott osztaly
{
	// input portok 
	sc_in<bool>		reset;
	sc_in<bool>		enable;
	sc_in<bool>		clk;
	sc_in<bool>		serial_in;
	// output port
	sc_out<sc_uint<16> >	shftreg;
	// belso regiszter
	unsigned short	reg;

	// ez a fo metodus, amiben a mukodes zajlik. Ebben hivjuk meg az "eredeti" C kodot.
	void	shiftreg_cthread()
	{
		while (1) {
			if (reset.read() == 0) {					
				reg = 0;	// alacsony aktiv reset
			} else {
				// az "eredeti" C kod meghivasa
				reg= shiftreg( enable.read(), serial_in.read(), reg );
			}
			// az eredmeny kiirasa
			shftreg.write(reg);
#ifdef _DEBUG
			// az stdoutra a tesztelo kod
			cout << setw(10) << sc_time_stamp();
			cout << setw(2) << enable;
			cout << setw(2) << reset;
			cout << setw(2) << serial_in;
			cout << setw(18) << bitset<16>(reg) << endl;
#endif
			wait();
		}
	}

	// konstruktor
	SC_CTOR(shiftreg_sc)
	{
		// ez lesz a mukodest leiro metodus
		SC_CTHREAD( shiftreg_cthread, clk.pos());
		// az orajel felfuto elere lesz erzekeny a modul
//		reset_signal_is(reset, false);
	}

};

#ifdef __CTOS__
SC_MODULE_EXPORT(shiftreg_sc);
#endif


