#include <systemc.h>
#include "shiftreg_sc.h"


int sc_main(int argc, char **argv)
{
	// a "top" modul jelei	
	sc_clock clk("CLK", 1.0, SC_NS);
	sc_signal<bool> reset("RESET");
	sc_signal<bool> enable("ENABLE");
	sc_signal<bool> serial_in("SERIAL_IN");
	sc_signal< sc_uint<16> > data("DATA");

	// a shiftregiszter peldanyositasa es bekotese
	shiftreg_sc shreg("SHIFTREG");
	shreg.clk(clk);
	shreg.reset(reset);
	shreg.enable(enable);
	shreg.serial_in(serial_in);
	shreg.shftreg(data);


	// trace file	
	sc_trace_file *fp;
	fp=sc_create_vcd_trace_file("wave");
	sc_trace(fp, clk, "clk");             
	sc_trace(fp, reset, "reset");
	sc_trace(fp, enable, "enable" );
	sc_trace(fp, serial_in, "serial_in");
	sc_trace(fp, data, "data");

	// itt kezdodik a szimulacio
	// reset
	reset= false;
	sc_start(2, SC_NS);

	// 1 db egyest beleptetunk
	reset = true;
	enable = true;
	serial_in = true;
	sc_start(1, SC_NS);
	serial_in = false;
	// 16 -szor shifteljuk
	sc_start(16, SC_NS);
	
	// takaritas
	sc_close_vcd_trace_file(fp);
	return 0;
	
}
