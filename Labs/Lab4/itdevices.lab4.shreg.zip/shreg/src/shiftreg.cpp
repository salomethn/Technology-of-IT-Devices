/**********************************************************
	Ez a file tartalmazza az "eredeti" C-ben irt kodot
	Ezt fogjuk elokesziteni szintezisre
**********************************************************/

unsigned short	shiftreg( bool enable, bool serial_in, unsigned short data)
{
	return enable ? ( (data<<1) | serial_in) : data;
}
